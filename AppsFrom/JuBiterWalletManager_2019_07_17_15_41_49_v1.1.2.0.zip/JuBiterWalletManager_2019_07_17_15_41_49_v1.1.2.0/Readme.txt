Simple Guide:

1.Run JuBiterWalletManager_shortcut or JuBiterWalletManager.exe as administrator.

2.Quick start
  a.Select the reader and click (Re)open button.
      HID Reader -> JuBiter Wallet_00
  b.Click AUTH button to establish secure channel with SCP protocol which you'd like to choose (Your sample is SCP02, which we have set it as default)
  c.Switch to Card Manager panel and double click the AID item, the Load Cap File dialog will show.
  d.Browse you cap file and click LoadAndInstall button, the application's instance will be installed with default AID.
  e.Right click the Application's AID to select the item from popup menu or double click it to select application instance.
  f.Right click the Application's AID or the ELF's AID to delete the instance or ELF. Make sure the secure channel had already been extablished.
  
3.Others
  a.The configuration files for SCP protocol are placed in JuBiterWalletManager folder. e.g.'scp02keys.json', 'scp11keys.json' etc.
  b.You can send pure APDU command with Command Shell panel.
  c.You can get the attribute of the wallet from WalletManager panel.
  d.If any crash happend restart the JuBiterWalletManager.exe ^_^!